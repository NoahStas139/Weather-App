document.addEventListener('DOMContentLoaded', function() {
    const cityForm = document.getElementById('cityForm');
    const weatherData = [
        {
            "cityName": "Dublin",
            "temperatureCelsius": 20,
            "humidity": 0.5,
            "uvIndex": 20,
            "windSpeed": "30km"
        },
        {
            "cityName": "New York",
            "temperatureCelsius": 6,
            "humidity": 0.76,
            "uvIndex": 2,
            "windSpeed": "15km"
        },
        {
            "cityName": "Tokyo",
            "temperatureCelsius": 11,
            "humidity": 0.45,
            "uvIndex": 2,
            "windSpeed": "20km"
        },
        {
            "cityName": "Sydney",
            "temperatureCelsius": 25,
            "humidity": 0.78,
            "uvIndex": 11,
            "windSpeed": "18km"
        },
        {
            "cityName": "Berlin",
            "temperatureCelsius": 9,
            "humidity": 0.84,
            "uvIndex": 2,
            "windSpeed": "25km"
        }
    ];

    // Handle city form submission
    if (cityForm) {
        cityForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const cityInput = document.getElementById('cityInput');
            const city = cityInput.value.trim();
            updateWeatherInfo(city);
        });
    }

    // Update weather information based on city
    function updateWeatherInfo(city) {
        const cityData = weatherData.find(data =>
            data.cityName.toLowerCase() === city.toLowerCase()
        );

        if (!cityData) {
            alert('City not found! Available cities: Dublin, New York, Tokyo, Sydney, Berlin');
            return;
        }

        // Update temperature
        const tempElement = document.getElementById('temperature');
        if (tempElement) {
            tempElement.textContent = `${cityData.temperatureCelsius}°C`;
            updateTempIcon(cityData.temperatureCelsius);
        }

        // Update humidity
        const humidityElement = document.getElementById('humidity');
        if (humidityElement) {
            humidityElement.textContent = `${(cityData.humidity * 100).toFixed(0)}%`;
            updateHumidityIcon(cityData.humidity);
        }

        // Update UV Index
        const uvElement = document.getElementById('uvIndex');
        if (uvElement) {
            uvElement.textContent = cityData.uvIndex;
            updateUVIcon(cityData.uvIndex);
        }

        // Update Wind Speed
        const windElement = document.getElementById('windSpeed');
        if (windElement) {
            windElement.textContent = cityData.windSpeed;
            updateWindIcon(parseInt(cityData.windSpeed));
        }
    }

    // Temperature icon color update
    function updateTempIcon(temp) {
        const icon = document.querySelector('.temp-icon');
        if (icon) {
            icon.style.color = temp > 20 ? '#ff9900' : '#3498db';
        }
    }

    // Humidity icon color update
    function updateHumidityIcon(humidity) {
        const icon = document.querySelector('.humidity-icon');
        if (icon) {
            icon.style.color = humidity > 0.7 ? '#3498db' : '#87ceeb';
        }
    }

    // UV Index icon color update
    function updateUVIcon(uv) {
        const icon = document.querySelector('.uv-icon');
        if (icon) {
            icon.style.color = uv > 5 ? '#ff4444' : '#ffeb3b';
        }
    }

    // Wind Speed icon color update
    function updateWindIcon(speed) {
        const icon = document.querySelector('.wind-icon');
        if (icon) {
            icon.style.color = speed > 20 ? '#95a5a6' : '#bdc3c7';
        }
    }

    // Temperature toggle functionality
    const tempToggle = document.getElementById('tempToggle');
    if (tempToggle) {
        tempToggle.addEventListener('click', function() {
            const tempElement = document.getElementById('temperature');
            if (!tempElement) return;

            const currentTemp = tempElement.textContent;
            if (currentTemp === '--°C') return;

            const tempValue = parseFloat(currentTemp);

            if (currentTemp.includes('°C')) {
                const fahrenheit = (tempValue * 9/5) + 32;
                tempElement.textContent = `${fahrenheit.toFixed(1)}°F`;
                tempToggle.textContent = 'Switch to Celsius';
            } else {
                const celsius = (tempValue - 32) * 5/9;
                tempElement.textContent = `${celsius.toFixed(1)}°C`;
                tempToggle.textContent = 'Switch to Fahrenheit';
            }
        });
    }
});
